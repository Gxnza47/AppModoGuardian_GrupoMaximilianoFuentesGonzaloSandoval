# AppModoGuardian_GrupoMaximilianoFuentesGonzaloSandoval

Proyecto Android desarrollado con **Kotlin + Jetpack Compose + Material 3**, organizado con **MVVM** y adaptado a distintos tamaños mediante **Window Size Classes**.

## Implementación de la Guía 9

La actividad quedó integrada sobre el proyecto existente:

- `ui/screens/`: contiene las vistas **Compact**, **Medium** y **Expanded**, además del `HomeScreen` que decide cuál mostrar.
- `ui/utils/WindowSizeUtils.kt`: utilidad reutilizable para calcular el `WindowWidthSizeClass`.
- `viewmodel/`: contiene `GuardianViewModel` para manejar el estado y las acciones de presentación.
- `model/`: contiene `GuardianUiState`.
- `repository/`: contiene `GuardianRepository` con datos iniciales simulados.
- `res/drawable/modo_guardian_banner.png`: imagen utilizada dentro de la interfaz.
- Cada variante tiene su propio `@Preview`.
- `TRELLO.md`: checklist de trazabilidad de la actividad.
- `DEVICE_SETUP.md`: dimensiones sugeridas para comprobar las tres variantes en Device Manager.

## Adaptabilidad

La aplicación obtiene la clase de ancho de la ventana y selecciona automáticamente:

- **Compact:** diseño vertical para teléfonos.
- **Medium:** distribución en dos columnas.
- **Expanded:** panel con navegación lateral y contenido distribuido para pantallas grandes.

## Prueba en Android Studio

Abre el proyecto en Android Studio, sincroniza Gradle y crea/selecciona emuladores con tamaños similares a los indicados en `DEVICE_SETUP.md`. El Device Manager es una configuración local del entorno de Android Studio y no se incluye como configuración portable del código fuente.

## Repositorio

Repositorio del proyecto:
https://github.com/Gxnza47/AppModoGuardian_GrupoMaximilianoFuentesGonzaloSandoval
