# Trazabilidad de la Guía 9

Este archivo deja preparada la división de tareas para replicarla en un tablero Trello del grupo.

## Por hacer / comprobación

- [x] Revisar la estructura MVVM existente.
- [x] Crear `ui/screens/`.
- [x] Crear `model/`, `viewmodel/` y `repository/`.
- [x] Crear `ui/utils/WindowSizeUtils.kt`.
- [x] Agregar `material3-window-size-class`.
- [x] Implementar vista Compact.
- [x] Implementar vista Medium.
- [x] Implementar vista Expanded.
- [x] Agregar `@Preview` a cada vista.
- [x] Agregar imagen en `res/drawable/`.
- [x] Conectar la selección de vista desde `MainActivity`.
- [ ] Crear/seleccionar dispositivos en Android Studio Device Manager y comprobar las tres variantes.
- [ ] Registrar el trabajo realizado en el tablero Trello del grupo.

## Propuesta de columnas Trello

**Pendiente → En desarrollo → En revisión → Terminado**
