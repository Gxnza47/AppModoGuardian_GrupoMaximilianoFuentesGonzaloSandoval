package com.example.modoguardian_grupomg.ui.screens

import androidx.compose.material3.windowsizeclass.WindowWidthSizeClass
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.modoguardian_grupomg.viewmodel.GuardianViewModel

@Composable
fun HomeScreen(
    windowSize: WindowWidthSizeClass,
    viewModel: GuardianViewModel = viewModel()
) {
    val uiState by viewModel.uiState.collectAsState()

    when (windowSize) {
        WindowWidthSizeClass.Compact -> {
            CompactHomeScreen(
                uiState = uiState,
                onEmergencyClick = viewModel::activateEmergencyAlert,
                onToggleGuardian = viewModel::toggleGuardian
            )
        }
        WindowWidthSizeClass.Medium -> {
            MediumHomeScreen(
                uiState = uiState,
                onEmergencyClick = viewModel::activateEmergencyAlert,
                onToggleGuardian = viewModel::toggleGuardian
            )
        }
        WindowWidthSizeClass.Expanded -> {
            ExpandedHomeScreen(
                uiState = uiState,
                onEmergencyClick = viewModel::activateEmergencyAlert,
                onToggleGuardian = viewModel::toggleGuardian
            )
        }
        else -> {
            CompactHomeScreen(
                uiState = uiState,
                onEmergencyClick = viewModel::activateEmergencyAlert,
                onToggleGuardian = viewModel::toggleGuardian
            )
        }
    }
}
