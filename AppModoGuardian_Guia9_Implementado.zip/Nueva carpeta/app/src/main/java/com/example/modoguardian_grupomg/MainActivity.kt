package com.example.modoguardian_grupomg

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.material3.windowsizeclass.ExperimentalMaterial3WindowSizeClassApi
import com.example.modoguardian_grupomg.ui.screens.HomeScreen
import com.example.modoguardian_grupomg.ui.theme.ModoGuardian_GrupoMGTheme
import com.example.modoguardian_grupomg.ui.utils.getWindowWidthSizeClass

class MainActivity : ComponentActivity() {
    @OptIn(ExperimentalMaterial3WindowSizeClassApi::class)
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            ModoGuardian_GrupoMGTheme {
                val windowSize = getWindowWidthSizeClass(this)
                HomeScreen(windowSize = windowSize)
            }
        }
    }
}
