package com.example.modoguardian_grupomg.ui.screens

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.weight
import androidx.compose.material3.Button
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import com.example.modoguardian_grupomg.model.GuardianUiState
import com.example.modoguardian_grupomg.ui.theme.ModoGuardian_GrupoMGTheme

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun MediumHomeScreen(
    uiState: GuardianUiState,
    onEmergencyClick: () -> Unit,
    onToggleGuardian: () -> Unit
) {
    Scaffold(
        topBar = { TopAppBar(title = { Text("Modo Guardián") }) }
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .padding(20.dp),
            verticalArrangement = Arrangement.spacedBy(18.dp)
        ) {
            Text(
                "Panel de protección",
                style = MaterialTheme.typography.headlineMedium,
                fontWeight = FontWeight.Bold
            )
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .weight(1f),
                horizontalArrangement = Arrangement.spacedBy(18.dp)
            ) {
                GuardianBanner(
                    modifier = Modifier
                        .weight(1.05f)
                        .fillMaxHeight(),
                    imageModifier = Modifier.fillMaxSize()
                )
                Column(
                    modifier = Modifier
                        .weight(0.95f)
                        .fillMaxHeight(),
                    verticalArrangement = Arrangement.spacedBy(14.dp)
                ) {
                    StatusCard(
                        uiState = uiState,
                        onToggleGuardian = onToggleGuardian,
                        modifier = Modifier.fillMaxWidth()
                    )
                    AlertsCard(
                        uiState = uiState,
                        modifier = Modifier.fillMaxWidth()
                    )
                    ProtectionSummary(
                        uiState = uiState,
                        modifier = Modifier.fillMaxWidth()
                    )
                    Button(
                        onClick = onEmergencyClick,
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Text("Enviar alerta")
                    }
                }
            }
        }
    }
}

@Preview(showBackground = true, widthDp = 700, heightDp = 800)
@Composable
fun MediumHomeScreenPreview() {
    ModoGuardian_GrupoMGTheme {
        MediumHomeScreen(
            uiState = GuardianUiState(),
            onEmergencyClick = {},
            onToggleGuardian = {}
        )
    }
}
