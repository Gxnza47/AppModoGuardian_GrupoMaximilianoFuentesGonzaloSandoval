package com.example.modoguardian_grupomg.repository

import com.example.modoguardian_grupomg.model.GuardianUiState

class GuardianRepository {
    fun getInitialState(): GuardianUiState = GuardianUiState()
}
