package com.example.modoguardian_grupomg.model

data class GuardianUiState(
    val isGuardianActive: Boolean = true,
    val pendingAlerts: Int = 0,
    val protectedPeople: Int = 2,
    val lastCheck: String = "Hace 2 minutos"
)
