package com.example.modoguardian_grupomg.ui.screens

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import com.example.modoguardian_grupomg.model.GuardianUiState
import com.example.modoguardian_grupomg.ui.theme.ModoGuardian_GrupoMGTheme

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun CompactHomeScreen(
    uiState: GuardianUiState,
    onEmergencyClick: () -> Unit,
    onToggleGuardian: () -> Unit
) {
    Scaffold(
        topBar = { TopAppBar(title = { Text("Modo Guardián") }) }
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .verticalScroll(rememberScrollState())
                .padding(innerPadding)
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Text(
                "Tu seguridad, siempre contigo",
                style = MaterialTheme.typography.headlineSmall,
                fontWeight = FontWeight.Bold
            )
            Text(
                "Monitoreo y seguridad en tiempo real para tu tranquilidad.",
                style = MaterialTheme.typography.bodyMedium
            )
            GuardianBanner(modifier = Modifier.fillMaxWidth())
            StatusCard(
                uiState = uiState,
                onToggleGuardian = onToggleGuardian,
                modifier = Modifier.fillMaxWidth()
            )
            AlertsCard(
                uiState = uiState,
                modifier = Modifier.fillMaxWidth()
            )
            ProtectionSummary(
                uiState = uiState,
                modifier = Modifier.fillMaxWidth()
            )
            Button(
                onClick = onEmergencyClick,
                modifier = Modifier.fillMaxWidth()
            ) {
                Text("Activar alerta de emergencia")
            }
        }
    }
}

@Preview(showBackground = true, widthDp = 360, heightDp = 760)
@Composable
fun CompactHomeScreenPreview() {
    ModoGuardian_GrupoMGTheme {
        CompactHomeScreen(
            uiState = GuardianUiState(),
            onEmergencyClick = {},
            onToggleGuardian = {}
        )
    }
}
