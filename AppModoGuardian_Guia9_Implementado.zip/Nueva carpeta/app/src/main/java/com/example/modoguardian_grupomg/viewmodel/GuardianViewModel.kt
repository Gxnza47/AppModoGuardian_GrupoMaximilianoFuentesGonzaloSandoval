package com.example.modoguardian_grupomg.viewmodel

import androidx.lifecycle.ViewModel
import com.example.modoguardian_grupomg.model.GuardianUiState
import com.example.modoguardian_grupomg.repository.GuardianRepository
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

class GuardianViewModel(
    private val repository: GuardianRepository = GuardianRepository()
) : ViewModel() {

    private val _uiState = MutableStateFlow(repository.getInitialState())
    val uiState: StateFlow<GuardianUiState> = _uiState.asStateFlow()

    fun toggleGuardian() {
        val current = _uiState.value
        _uiState.value = current.copy(isGuardianActive = !current.isGuardianActive)
    }

    fun activateEmergencyAlert() {
        val current = _uiState.value
        _uiState.value = current.copy(pendingAlerts = current.pendingAlerts + 1)
    }
}
