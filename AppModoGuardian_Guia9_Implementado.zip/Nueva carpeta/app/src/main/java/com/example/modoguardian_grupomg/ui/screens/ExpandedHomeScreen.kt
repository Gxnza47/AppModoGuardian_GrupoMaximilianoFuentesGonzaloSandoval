package com.example.modoguardian_grupomg.ui.screens

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationRail
import androidx.compose.material3.NavigationRailItem
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import com.example.modoguardian_grupomg.model.GuardianUiState
import com.example.modoguardian_grupomg.ui.theme.ModoGuardian_GrupoMGTheme

@Composable
fun ExpandedHomeScreen(
    uiState: GuardianUiState,
    onEmergencyClick: () -> Unit,
    onToggleGuardian: () -> Unit
) {
    Scaffold { innerPadding ->
        Row(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding),
            horizontalArrangement = Arrangement.spacedBy(24.dp)
        ) {
            NavigationRail(modifier = Modifier.fillMaxHeight()) {
                NavigationRailItem(
                    selected = true,
                    onClick = {},
                    icon = { Text("⌂") },
                    label = { Text("Inicio") }
                )
                NavigationRailItem(
                    selected = false,
                    onClick = {},
                    icon = { Text("!") },
                    label = { Text("Alertas") }
                )
                NavigationRailItem(
                    selected = false,
                    onClick = {},
                    icon = { Text("⚙") },
                    label = { Text("Ajustes") }
                )
            }

            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(vertical = 28.dp, horizontal = 8.dp),
                verticalArrangement = Arrangement.spacedBy(20.dp)
            ) {
                Text(
                    "Modo Guardián",
                    style = MaterialTheme.typography.displaySmall,
                    fontWeight = FontWeight.Bold
                )
                Text(
                    "Panel adaptado para pantallas grandes",
                    style = MaterialTheme.typography.bodyLarge
                )

                Row(
                    modifier = Modifier.fillMaxSize(),
                    horizontalArrangement = Arrangement.spacedBy(20.dp)
                ) {
                    GuardianBanner(
                        modifier = Modifier
                            .weight(1f)
                            .fillMaxHeight(),
                        imageModifier = Modifier.fillMaxSize()
                    )
                    Column(
                        modifier = Modifier
                            .weight(1f)
                            .fillMaxHeight(),
                        verticalArrangement = Arrangement.spacedBy(16.dp)
                    ) {
                        StatusCard(
                            uiState = uiState,
                            onToggleGuardian = onToggleGuardian
                        )
                        Row(horizontalArrangement = Arrangement.spacedBy(16.dp)) {
                            AlertsCard(
                                uiState = uiState,
                                modifier = Modifier.weight(1f)
                            )
                            ProtectionSummary(
                                uiState = uiState,
                                modifier = Modifier.weight(1f)
                            )
                        }
                        Card(modifier = Modifier.weight(1f).fillMaxWidth()) {
                            Column(
                                modifier = Modifier
                                    .fillMaxSize()
                                    .padding(22.dp),
                                verticalArrangement = Arrangement.spacedBy(12.dp)
                            ) {
                                Text(
                                    "Acciones rápidas",
                                    style = MaterialTheme.typography.titleLarge,
                                    fontWeight = FontWeight.Bold
                                )
                                Text(
                                    "Usa el botón para registrar una alerta de emergencia desde el panel principal."
                                )
                                Button(
                                    onClick = onEmergencyClick,
                                    modifier = Modifier.width(220.dp)
                                ) {
                                    Text("Activar emergencia")
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

@Preview(showBackground = true, widthDp = 1200, heightDp = 800)
@Composable
fun ExpandedHomeScreenPreview() {
    ModoGuardian_GrupoMGTheme {
        ExpandedHomeScreen(
            uiState = GuardianUiState(),
            onEmergencyClick = {},
            onToggleGuardian = {}
        )
    }
}
