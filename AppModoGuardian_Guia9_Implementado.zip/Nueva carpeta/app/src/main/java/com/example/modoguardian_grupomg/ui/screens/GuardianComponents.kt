package com.example.modoguardian_grupomg.ui.screens

import androidx.compose.foundation.Image
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Card
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.modoguardian_grupomg.R
import com.example.modoguardian_grupomg.model.GuardianUiState

@Composable
fun GuardianBanner(
    modifier: Modifier = Modifier,
    imageModifier: Modifier = Modifier.fillMaxWidth()
) {
    Card(
        modifier = modifier,
        shape = RoundedCornerShape(20.dp)
    ) {
        Image(
            painter = painterResource(R.drawable.modo_guardian_banner),
            contentDescription = "Ilustración de Modo Guardián",
            modifier = imageModifier,
            contentScale = ContentScale.Crop
        )
    }
}

@Composable
fun StatusCard(
    uiState: GuardianUiState,
    onToggleGuardian: () -> Unit,
    modifier: Modifier = Modifier
) {
    Card(modifier = modifier) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column {
                Text("Estado de protección", fontWeight = FontWeight.Bold)
                Text(
                    if (uiState.isGuardianActive) "Activo" else "Inactivo",
                    color = if (uiState.isGuardianActive) {
                        MaterialTheme.colorScheme.primary
                    } else {
                        MaterialTheme.colorScheme.error
                    }
                )
            }
            Switch(
                checked = uiState.isGuardianActive,
                onCheckedChange = { onToggleGuardian() }
            )
        }
    }
}

@Composable
fun AlertsCard(
    uiState: GuardianUiState,
    modifier: Modifier = Modifier
) {
    Card(modifier = modifier) {
        Column(modifier = Modifier.padding(16.dp)) {
            Text("Alertas", fontWeight = FontWeight.Bold)
            Text(
                text = if (uiState.pendingAlerts == 0) {
                    "Sin alertas pendientes"
                } else {
                    "${uiState.pendingAlerts} pendientes"
                },
                color = if (uiState.pendingAlerts == 0) {
                    MaterialTheme.colorScheme.primary
                } else {
                    MaterialTheme.colorScheme.error
                }
            )
        }
    }
}

@Composable
fun ProtectionSummary(
    uiState: GuardianUiState,
    modifier: Modifier = Modifier
) {
    Card(modifier = modifier) {
        Column(modifier = Modifier.padding(16.dp)) {
            Text("Resumen", fontWeight = FontWeight.Bold)
            Text("Personas protegidas: ${uiState.protectedPeople}")
            Text("Última revisión: ${uiState.lastCheck}")
        }
    }
}
