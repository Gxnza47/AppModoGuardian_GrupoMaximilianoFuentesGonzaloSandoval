# Dispositivos sugeridos para probar la Guía 9

La guía solicita probar distintos tamaños de dispositivo. Para comprobar exactamente las tres variantes implementadas, se sugieren estas configuraciones en Android Studio Device Manager:

| Variante | Ancho | Alto | Uso |
|---|---:|---:|---|
| Compact | 360 dp | 760 dp | Teléfono |
| Medium | 700 dp | 800 dp | Tablet/ventana mediana |
| Expanded | 1200 dp | 800 dp | Tablet/ventana grande |

La aplicación usa el ancho de la ventana mediante `WindowWidthSizeClass` y cambia automáticamente entre Compact, Medium y Expanded.

El Device Manager es una configuración local de Android Studio, por lo que no se genera como parte portable del código fuente del ZIP.
